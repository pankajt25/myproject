const rl = require("readline").createInterface({ input: process.stdin, output: process.stdout });

rl.question("Enter a number: ", n => {
    n = Number(n);
    let prime = n > 1;

    for (let i = 2; i <= Math.sqrt(n) && prime; i++)
        if (n % i === 0) prime = false;

    console.log(prime ? "Prime Number" : "Not Prime Number");
    rl.close();
});